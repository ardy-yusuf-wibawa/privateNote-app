import React from 'react'

const Card = (props) => {
  const classes =
    ' card w-[300px] h-[280px] bg-gray-400 rounded-md bg-clip-padding backdrop-filter backdrop-blur-sm bg-opacity-10 border border-gray-100' +
    props.className

  return <div className={classes}>{props.children}</div>
}

export default Card
