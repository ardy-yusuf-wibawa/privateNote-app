import React from 'react'
import Card from '../UI/Card'
import NotesDate from './NotesDate'

const NotesItem = (props) => {
  return (
    <Card className='flex py-2 px-2 '>
      <div className='card-body'>
        <div className='flex justify-between gap-1 text-xs'>
          <h2 className='card-title'>{props.title}</h2>
          <NotesDate createdAt={props.createdAt} />
        </div>
        <p className=' text-xs'>{props.body}</p>
        <div className='card-actions justify-end'>{props.children}</div>
      </div>
    </Card>
  )
}

export default NotesItem
