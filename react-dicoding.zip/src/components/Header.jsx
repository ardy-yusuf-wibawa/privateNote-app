import React from 'react'

export default function Header({ setSearchQuery }) {
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value)
  }

  return (
    <div className='navbar h-[5%] w-[100%] px-[2%] bg-slate-500 bg-clip-padding backdrop-filter backdrop-blur-sm bg-opacity-20 border-b-2 border-slate-700'>
      <div className='flex-1'>
        <a className='btn btn-ghost normal-case text-xl font-comic'>NOTES</a>
      </div>
      <div className='flex-none gap-2'>
        <div className='form-control'>
          <input
            type='text'
            placeholder='Search in Title & Body'
            className='input input-bordered w-[192px] sm:w-[30rem]'
            onChange={handleSearchChange}
          />
        </div>
      </div>
    </div>
  )
}
