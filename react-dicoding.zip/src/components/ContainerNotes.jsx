import React from 'react'
import NotesItem from './NotesItem'

export default function ContainerNotes(props) {
  const handleMoveToArchived = (id) => {
    props.onMoveToArchived(id)
  }

  const handleMoveToNonArchived = (id) => {
    props.onMoveToNonArchived(id)
  }

  const handleDelete = (id) => {
    props.onDelete(id)
  }

  return (
    <>
      <h2>Notes</h2>
      <div className='flex justify-between items-center w-[33%] h-[20%]'>
        {props.nonArchivedData.length === 0 ? (
          <div className='m-auto pt-[50%]'>
            <div className='alert alert-warning'>
              <svg
                xmlns='http://www.w3.org/2000/svg'
                className='stroke-current shrink-0 h-6 w-6'
                fill='none'
                viewBox='0 0 24 24'>
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  strokeWidth='2'
                  d='M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'
                />
              </svg>
              <span>Tidak ada Catatan</span>
            </div>
          </div>
        ) : (
          <ul className='grid grid-rows-3 grid-flow-col gap-4'>
            {props.nonArchivedData.map((item) => (
              <li key={item.id}>
                <NotesItem
                  title={item.title}
                  body={item.body}
                  createdAt={item.createdAt}>
                  <button
                    className='h-8 w-40 bg-gray-400 rounded-md bg-clip-padding backdrop-filter backdrop-blur-sm bg-opacity-10 border border-gray-100 text-emerald-500 '
                    onClick={() => handleMoveToArchived(item.id)}>
                    Move to Archived
                  </button>
                  <button
                    className='btn btn-circle btn-sm bg-gray-400 rounded-md bg-clip-padding backdrop-filter backdrop-blur-sm bg-opacity-10 border border-gray-200'
                    onClick={() => handleDelete(item.id)}>
                    <svg
                      xmlns='http://www.w3.org/2000/svg'
                      className='h-6 w-6'
                      fill='none'
                      viewBox='0 0 24 24'
                      stroke='red'>
                      <path
                        strokeLinecap='round'
                        strokeLinejoin='round'
                        strokeWidth='2'
                        d='M6 18L18 6M6 6l12 12'
                      />
                    </svg>
                  </button>
                </NotesItem>
              </li>
            ))}
          </ul>
        )}
      </div>

      <h2>Archived</h2>
      <div className='flex flex-row justify-between items-center w-[33%] h-[20%]'>
        {props.archivedData.length === 0 ? (
          <div className='m-auto pt-[50%]'>
            <div className='alert alert-warning'>
              <svg
                xmlns='http://www.w3.org/2000/svg'
                className='stroke-current shrink-0 h-6 w-6'
                fill='none'
                viewBox='0 0 24 24'>
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  strokeWidth='2'
                  d='M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'
                />
              </svg>
              <span>Tidak ada Catatan</span>
            </div>
          </div>
        ) : (
          <ul className='grid grid-rows-3 grid-flow-col gap-4'>
            {props.archivedData.map((item) => (
              <li key={item.id}>
                <NotesItem
                  title={item.title}
                  body={item.body}
                  createdAt={item.createdAt}>
                  <button
                    className='h-8 w-40 bg-gray-400 rounded-md bg-clip-padding backdrop-filter backdrop-blur-sm bg-opacity-10 border border-gray-100 text-emerald-500 '
                    onClick={() => handleMoveToNonArchived(item.id)}>
                    Move to Notes
                  </button>
                  <button
                    className='btn btn-circle btn-sm bg-gray-400 rounded-md bg-clip-padding backdrop-filter backdrop-blur-sm bg-opacity-10 border border-gray-200'
                    onClick={() => handleDelete(item.id)}>
                    <svg
                      xmlns='http://www.w3.org/2000/svg'
                      className='h-6 w-6'
                      fill='none'
                      viewBox='0 0 24 24'
                      stroke='red'>
                      <path
                        strokeLinecap='round'
                        strokeLinejoin='round'
                        strokeWidth='2'
                        d='M6 18L18 6M6 6l12 12'
                      />
                    </svg>
                  </button>
                </NotesItem>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  )
}
