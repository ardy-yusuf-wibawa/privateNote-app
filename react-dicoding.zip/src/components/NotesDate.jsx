import React from 'react'

export default function NotesDate(props) {
  const formatDate = (isoDate) => {
    const date = new Date(isoDate)
    const day = date.getDate().toString().padStart(2, '0')
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const year = date.getFullYear()
    return `${day}/${month}/${year}`
  }
  return (
    <>
      <span className='leading-[28px]'>{formatDate(props.createdAt)}</span>
    </>
  )
}
