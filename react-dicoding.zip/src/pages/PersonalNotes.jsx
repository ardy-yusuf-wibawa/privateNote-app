import React, { useState, useEffect } from 'react'
import Header from '../components/Header'
import InputForm from '../components/InputForm'
import ContainerNotes from '../components/ContainerNotes'
import { getInitialData } from '../utils'

export default function PersonalNotes() {
  const initialNotes = getInitialData()
  const [notes, setNotes] = useState(initialNotes)
  const [nonArchivedData, setNonArchivedData] = useState([])
  const [archivedData, setArchivedData] = useState([])
  const [searchQuery, setSearchQuery] = useState('')

  const onAddNotes = ({ title, body, archived }) => {
    setNotes((prevNotes) => {
      return [
        ...prevNotes,
        {
          id: +new Date(),
          title,
          body,
          createdAt: new Date().toISOString(),
          archived
        }
      ]
    })
  }

  useEffect(() => {
    const newNotes = notes.filter((item) => !item.archived)
    const newArchived = notes.filter((item) => item.archived)

    setNonArchivedData(newNotes)
    setArchivedData(newArchived)
  }, [notes])

  const moveNoteToArchived = (id) => {
    const noteToMove = nonArchivedData.find((note) => note.id === id)

    if (noteToMove) {
      noteToMove.archived = true

      setNonArchivedData(nonArchivedData.filter((note) => note.id !== id))

      setArchivedData([...archivedData, noteToMove])
    }
  }

  const moveNoteToNonArchived = (id) => {
    const noteToMove = archivedData.find((note) => note.id === id)

    if (noteToMove) {
      noteToMove.archived = false

      setArchivedData(archivedData.filter((note) => note.id !== id))

      setNonArchivedData([...nonArchivedData, noteToMove])
    }
  }

  const onDeleteHandler = (id) => {
    const updatedNotes = notes.filter((note) => note.id !== id)
    setNotes(updatedNotes)
  }

  const filteredNonArchivedData = nonArchivedData.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.body.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const filteredArchivedData = archivedData.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.body.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className='w-full h-full'>
      <Header setSearchQuery={setSearchQuery} />
      <div className='flex items-start justify-between gap-2'>
        <InputForm
          addNotes={onAddNotes}
          className='w-[33%]'
        />
        <ContainerNotes
          nonArchivedData={filteredNonArchivedData}
          archivedData={filteredArchivedData}
          onMoveToArchived={moveNoteToArchived}
          onMoveToNonArchived={moveNoteToNonArchived}
          onDelete={onDeleteHandler}
          className='w-[66%]'
        />
      </div>
    </div>
  )
}
